﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MvcApplication1.Models
{
    interface IProductsRepository
    {
        IQueryable<Product> FindAllProducts();

        Product FindProductById(int id);

        Product GetProduct(int id);

        void Update(Product service);

        void Add(Product service);

        void Delete(Product service);

        void Save();
    }
}
