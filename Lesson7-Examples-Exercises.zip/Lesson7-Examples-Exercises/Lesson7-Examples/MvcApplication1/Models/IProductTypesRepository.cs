﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MvcApplication1.Models
{
    interface IProductTypesRepository
    {

            IQueryable<ProductType> FindAllProductTypes();

            ProductType FindProductTypeById(int id);

            ProductType GetProductType(int id);

            void Update(ProductType service);

            void Add(ProductType service);

            void Delete(ProductType service);

            void Save();
    }
}
