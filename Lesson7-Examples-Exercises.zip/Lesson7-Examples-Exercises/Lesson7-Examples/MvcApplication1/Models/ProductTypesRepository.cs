﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.Data;

namespace MvcApplication1.Models
{
    public class ProductTypesRepository:IProductTypesRepository
    {

        private Golden_HolidaysEntities entities = new Golden_HolidaysEntities();
        
        public IQueryable<ProductType> FindAllProductTypes()
        {
            return entities.ProductTypes;
        }

        public ProductType FindProductTypeById(int id)
        {
            return entities.ProductTypes.FirstOrDefault(d => d.ProductTypeId == id);
        }

        public ProductType GetProductType(int id)
        {
            return entities.ProductTypes.FirstOrDefault(d => d.ProductTypeId == id);
        }

        public void Update(ProductType service)
        {
            entities.Entry(service).State = EntityState.Modified;
        }

        public void Add(ProductType service)
        {
            entities.ProductTypes.Add(service);
        }

        public void Delete(ProductType service)
        {
            entities.ProductTypes.Remove(service);
        }

        public void Save()
        {
            entities.SaveChanges();
        }
    }
}