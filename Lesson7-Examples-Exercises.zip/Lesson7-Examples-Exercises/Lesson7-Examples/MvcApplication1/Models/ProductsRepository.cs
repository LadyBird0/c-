﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication1.Models
{
    public class ProductsRepository:IProductsRepository 
    {
        private Golden_HolidaysEntities entities = new Golden_HolidaysEntities();

        public IQueryable<Product> FindAllProducts()
        {
            return entities.Products;
        }

        public Product FindProductById(int id)
        {
            return entities.Products.FirstOrDefault(d => d.ProductId == id);
        }

        public Product GetProduct(int id)
        {
            return entities.Products.FirstOrDefault(d => d.ProductId == id);
        }

        public void Update(Product service)
        {
            entities.Entry(service).State = EntityState.Modified;
        }

        public void Add(Product service)
        {
            entities.Products.Add(service);
        }

        public void Delete(Product service)
        {
            entities.Products.Remove(service);
        }

        public void Save()
        {
            entities.SaveChanges();
        }
    }
}