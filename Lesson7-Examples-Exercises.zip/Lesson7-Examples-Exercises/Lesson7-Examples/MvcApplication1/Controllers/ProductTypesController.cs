﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication1.Models;

namespace MvcApplication1.Controllers
{
    public class ProductTypesController : Controller
    {

        private IProductTypesRepository productTypesRepo = new ProductTypesRepository();
        
        //
        // GET: /ProductTypes/

        public ActionResult Index()
        {
            var productTypes = productTypesRepo.FindAllProductTypes().ToList();
            return View("Index", productTypes);
        }


        public ActionResult Details(int id)
        {
            ProductType productType = productTypesRepo.GetProductType(id);
            if (productType == null)
            {
                return View("NotFound");
            }
            else
            {
                return View("Details", productType);
            }
        }


        public ActionResult Create()
        {
            ProductType productType = new ProductType
            {
            };

            return View(productType);
        }


        [HttpPost]
        public ActionResult Create(FormCollection formValue)
        {
            ProductType productType = new ProductType
            {
            };

            if (TryUpdateModel(productType))
            {
                productTypesRepo.Add(productType);
                productTypesRepo.Save();

                return RedirectToAction("Details", new { id = productType.ProductTypeId });
            }
            return View(productType);
        }



        public ActionResult Delete(int id)
        {
            ProductType productType = productTypesRepo.GetProductType(id);
            if (productType == null)
                return View("Not Found");
            else
                return View(productType);
        }


        [HttpPost]
        public ActionResult Delete(int id, string confirmButton)
        {
            ProductType productType = productTypesRepo.GetProductType(id);
            if (productType == null)
                return View("Not Found");
            productTypesRepo.Delete(productType);
            productTypesRepo.Save();
            return View("Deleted");
        }




    }
}
