﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication1.Models;

namespace MvcApplication1.Controllers
{
    public class ProductsController : Controller
    {
        private IProductsRepository productsRepo = new ProductsRepository();

        public ActionResult Index()
        {
            var products = productsRepo.FindAllProducts().ToList();
            return View("Index", products);
        }


        public ActionResult Details(int id)
        {
            Product product = productsRepo.GetProduct(id);
            if (product == null)
            {
                return View("NotFound");
            }
            else
            {
                return View("Details", product);
            }
        }


        public ActionResult Edit(int id)
        {
            Product product = productsRepo.GetProduct(id);
            return View(product);
        }


        public ActionResult Create()
        {
            Product product = new Product
            {
                ProductTypeId = 1
            };
            return View(product);
        }

        [HttpPost]
        public ActionResult Edit(int id, FormCollection formValues)
        {
            Product product = productsRepo.GetProduct(id);

            product.ProductName = Request.Form["ProductName"];
            product.ProductDesc = Request.Form["ProductDesc"];

            productsRepo.Save();

            return RedirectToAction("Details", new { id = product.ProductId });
        }



        [HttpPost]
        public ActionResult Create(FormCollection formValue)
        {
            Product product = new Product
            {
                ProductTypeId = 1
            };

            if (TryUpdateModel(product))
            {
                productsRepo.Add(product);
                productsRepo.Save();

                return RedirectToAction("Details", new { id = product.ProductId });
            }
            return View(product);
        }

        public ActionResult Delete(int id)
        {
            Product product = productsRepo.GetProduct(id);
            if (product == null)
                return View("Not Found");
            else
                return View(product);
        }

        [HttpPost]
        public ActionResult Delete(int id, string confirmButton)
        {
            Product product = productsRepo.GetProduct(id);
            if (product == null)
                return View("Not Found");
            productsRepo.Delete(product);
            productsRepo.Save();
            return View("Deleted");
        }






    }
}
